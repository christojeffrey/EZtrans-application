class Pengguna:
    def __init__(self, idRute, idArmada, idAsal, idTujuan, tanggalKeberangkatan, jamBerangkat, jamTiba, harga, jumlahKursiTersedia):
        self.idRute = idRute
        self.idArmada = idArmada
        self.idAsal = idAsal
        self.tanggalKeberangkatan = tanggalKeberangkatan
        self.jamBerangkat = jamBerangkat
        self.jamTiba = jamTiba
        self.harga = harga
        self.jumlahKursiTersedia = jumlahKursiTersedia

    def getIdRute(self):
        return self.idRute

    def getIdArmada(self):
        return self.idArmada

    def getIdAsal(self):
        return self.idArmada
    
    def getIdTujuan(self):
        return self.idArmada

    def getTanggalKeberangkatan(self):
        return self.tanggalKeberangkatan
    
    def getJamBerangkat(self):
        return self.jamBerangkat

    def getJamTiba(self):
        return self.jamTiba
    
    def getHarga(self):
        return self.harga
    
    def getjumlahKursiTersedia(self):
        return self.jumlahKursiTersedia